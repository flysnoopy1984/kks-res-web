const carousel_vue_vue_type_style_index_0_scoped_921b14da_lang = ".carousel-img[data-v-921b14da]{height:240px;-o-object-fit:cover;object-fit:cover;width:100%}[data-v-921b14da] .creative-enter-from,[data-v-921b14da] .creative-leave-to{opacity:0;transform:scale(.8)}[data-v-921b14da] .creative-enter-active,[data-v-921b14da] .creative-leave-active{transition:all .3s ease}";

const index_vue_vue_type_style_index_0_scoped_48c3c7ac_lang = ".divIn[data-v-48c3c7ac]{align-items:center;display:flex;justify-content:center}";

const indexStyles_42f6bb8e = [carousel_vue_vue_type_style_index_0_scoped_921b14da_lang, index_vue_vue_type_style_index_0_scoped_48c3c7ac_lang, index_vue_vue_type_style_index_0_scoped_48c3c7ac_lang];

export { indexStyles_42f6bb8e as default };
//# sourceMappingURL=index-styles.42f6bb8e.mjs.map
