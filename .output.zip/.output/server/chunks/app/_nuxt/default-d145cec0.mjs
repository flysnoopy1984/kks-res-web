import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc, a as useHead } from '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main$2 = {
  __name: "mainHeader",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u5440\u54C8\u54C8\uFF0C\u798F\u5230\u4E86",
      meta: [
        { name: "description", content: "\u8D3A\u5361 \u9001\u795D\u798F \u6D77\u62A5" },
        { name: "charset", content: "utf-8" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "header-container" }, _attrs))}><header id="header-compact-v3" class="header-original should-stick"><div class="header-inner"><nav class="func-nav"><ul><li><button class="nav-category" title="\u5206\u7C7B" aria-label="\u5206\u7C7B"><svg xmlns="http://www.w3.org/2000/svg" width="10" height="7" viewBox="0 0 10 7" class="fill-current-color"><path fill="#a6a6a6" d="M0 0h10v.7H0zm0 2.1h10v.7H0zm0 2.1h10v.7H0zm0 2.1h10V7H0z"></path></svg><span class="text">\u5206\u7C7B</span></button></li><li><button class="nav-search" title="\u641C\u7D22" aria-label="\u641C\u7D22"><svg xmlns="http://www.w3.org/2000/svg" width="14" viewBox="0 0 14 14" class="fill-current-color"><path fill="#fff" d="M14 12.83l-2.19-2.19a6.61 6.61 0 10-1.17 1.17L12.83 14zM2.5 10.7a5.8 5.8 0 018.2-8.2 5.8 5.8 0 01-8.2 8.2z"></path></svg><span class="text">\u641C\u7D22</span></button></li></ul></nav><div class="site-nav-container"><nav class="site-nav site-nav-normal"><ul><li class="nav-item-original"><a href="/?dcs=original-featured&amp;dcm=normal-nav">\u539F\u521B</a></li><li class="nav-item-chart"><a href="/charts?dcs=original-featured&amp;dcm=normal-nav" class="">\u6392\u884C</a></li><li class="nav-item-ebook"><a href="/ebooks/?dcs=original-featured&amp;dcm=normal-nav" class="">\u51FA\u7248</a></li><li class="nav-item-membership"><a href="/membership/store/?dcs=original-featured&amp;dcm=normal-nav" class="">\u4F1A\u5458</a></li><li class="nav-item-app"><a href="/app?dcs=original-featured&amp;dcm=normal-nav" class="">App</a></li></ul></nav><nav class="site-nav site-nav-original"><ul><li class="nav-item-original"><a href="/?dcs=original-featured&amp;dcm=original-nav" class="active">\u539F\u521B\u9996\u9875</a></li><li class="nav-item-finalized"><a href="/original/finalized?dcs=original-featured&amp;dcm=original-nav" class="">\u5B8C\u672C</a></li><li class="nav-item-chart"><a href="/charts?dcs=original-featured&amp;dcm=original-nav" class="">\u6392\u884C</a></li><li class="nav-item-original/romance_fiction"><a href="/original/romance_fiction?dcs=original-featured&amp;dcm=original-nav" class="">\u8A00\u60C5</a></li><li class="nav-item-original/mystery_fiction"><a href="/original/mystery_fiction?dcs=original-featured&amp;dcm=original-nav" class="">\u60AC\u7591</a></li><li class="nav-item-original/womens_fiction"><a href="/original/womens_fiction?dcs=original-featured&amp;dcm=original-nav" class="">\u5973\u6027</a></li><li class="nav-item-original/science_fiction"><a href="/original/science_fiction?dcs=original-featured&amp;dcm=original-nav" class="">\u5E7B\u60F3</a></li><li class="nav-item-original/fanfiction"><a href="/original/fanfiction?dcs=original-featured&amp;dcm=original-nav" class="">\u540C\u4EBA</a></li><li class="nav-item-original/literary_fiction"><a href="/original/literary_fiction?dcs=original-featured&amp;dcm=original-nav" class="">\u6587\u827A</a></li><li class="nav-item-competition_all"><a href="/competition/all?dcs=original-featured&amp;dcm=original-nav" class="">\u5F81\u6587\u4E13\u533A</a></li><li class="nav-item-original_more more-active"><button class="btn-more" title="\u66F4\u591A\u5BFC\u822A" aria-label="\u66F4\u591A\u5BFC\u822A"></button></li><li class="nav-item-ebook"><a href="/ebooks/?dcs=original-featured&amp;dcm=original-nav" class="">\u51FA\u7248</a></li><li class="nav-item-membership"><a href="/membership/store/?dcs=original-featured&amp;dcm=original-nav" class="">\u4F1A\u5458</a></li><li class="nav-item-app"><a href="/app?dcs=original-featured&amp;dcm=original-nav" class="">App</a></li></ul></nav></div><div id="nav-submit" class="nav-submit"><a href="/submit" target="_blank" class="lnk-start-publish fill-current-color">\u6210\u4E3A\u4F5C\u8005</a></div><nav class="site-nav-right"><ul><li class="nav-cart"><a href="/account/wishlist?dcs=original-featured&amp;dcm=header" title="\u8D2D\u7269\u8F66" aria-label="\u8D2D\u7269\u8F66"><svg xmlns="http://www.w3.org/2000/svg" width="24" viewBox="0 0 24 24" class="fill-current-color"><path d="M19.5 18.2c-.8 0-1.4.6-1.4 1.4 0 .8.6 1.4 1.4 1.4.8 0 1.4-.6 1.4-1.4 0-.8-.6-1.4-1.4-1.4zm-12.7 0c-.8 0-1.4.6-1.4 1.4 0 .8.6 1.4 1.4 1.4s1.4-.6 1.4-1.4c0-.8-.6-1.4-1.4-1.4zM22.2 5.4H5l-.5-2c0-.2-.2-.4-.5-.4H1.5c-.3 0-.5.2-.5.5s.2.5.5.5h2.2l3.4 12.9c.1.2.3.4.5.4h12.8c.3 0 .5-.2.5-.5s-.2-.5-.5-.5H8l-.3-1.2H20c.6 0 1.1-.4 1.2-1L23 6.4c.1-.5-.3-1-.8-1zm-2 8.5c0 .1-.2.2-.2.2H7.4L5.3 6.4H22l-1.8 7.5z"></path></svg><span class="nav-num cart-count">1</span></a></li><li><button class="nav-noti" title="\u63D0\u9192" aria-label="\u63D0\u9192"><svg xmlns="http://www.w3.org/2000/svg" width="24" viewBox="0 0 24 24" class="fill-current-color"><path d="M20.5 17.6h-.6c-.8-.2-1.3-.8-1.3-1.6v-4.8c0-3-2.1-5.6-5-6.2.1-.2.2-.5.2-.7 0-.9-.8-1.7-1.7-1.7-.9 0-1.7.8-1.7 1.7 0 .3.1.5.2.7-2.9.7-5 3.2-5 6.2V16c0 .8-.6 1.5-1.3 1.6h-.8v1.2h5.7c.1 1.5 1.3 2.7 2.8 2.7 1.5 0 2.7-1.2 2.8-2.7h5.7v-1.2zM6.6 16v-4.8c0-3 2.4-5.3 5.4-5.3 3 0 5.4 2.4 5.4 5.3V16c0 .6.2 1.2.5 1.6H6.1c.3-.4.5-1 .5-1.6zm5.4 4.4c-.9 0-1.6-.7-1.7-1.6h3.3c0 .9-.7 1.6-1.6 1.6z"></path></svg><span class="nav-num noti-count">12</span></button></li><li class="nav-bookshelf"><a href="/bookshelf?dcs=original-featured&amp;dcm=header" title="\u4E66\u67B6" aria-label="\u4E66\u67B6" class="require-login"><svg xmlns="http://www.w3.org/2000/svg" width="24" viewBox="0 0 24 24" class="fill-current-color"><path d="M13.9 5.223l3.14 12.1a.23.23 0 00.284.165l2.332-.645a.233.233 0 00.162-.28l-3.14-12.1a.23.23 0 00-.284-.166l-2.332.645a.233.233 0 00-.162.28zM8.5 5h-3v12h3zm1 12h3V3h-3v14zm4-9.327V14.5h1.77zm0-3.57a1.212 1.212 0 01.293-.125l2.33-.645a1.232 1.232 0 011.516.86v.018l3.136 12.1a1.23 1.23 0 01-.863 1.5l-2.33.647a1.232 1.232 0 01-1.516-.86v-.018l-.537-2.08H13.5V17a1 1 0 01-1 1h-3a1 1 0 01-.5-.134 1 1 0 01-.5.134h-3a1 1 0 01-1-1v-1.5H1.822a.23.23 0 00-.23.227l-.074 5.04a.23.23 0 00.23.233h20.506a.23.23 0 00.228-.234l-.074-5.04a.23.23 0 00-.23-.226h-1.59l-.268-1h1.858a1.23 1.23 0 011.23 1.213l.074 5.038A1.23 1.23 0 0122.27 22H1.75a1.23 1.23 0 01-1.232-1.23v-.02l.074-5.037a1.23 1.23 0 011.23-1.213H4.5V5a1 1 0 011-1h3V3a1 1 0 011-1h3a1 1 0 011 1z"></path></svg></a></li></ul></nav><div class="user-info" id="user-info"><div class="nav-user more-active"><a title="Jacky" href="/mine" class="avatar"><img width="30" height="30" alt="Jacky" src="https://img2.doubanio.com/icon/up47115977-3.jpg"></a><div class="drop-down-list"><a href="/people/47115977/"><span class="text">\u4E2A\u4EBA\u4E3B\u9875</span></a><a href="/reading_history"><span class="text">\u9605\u8BFB\u8BB0\u5F55</span></a><a href="/account/reading_time"><span class="text">\u9605\u8BFB\u65F6\u957F</span></a><a href="/membership"><span class="text">\u4F1A\u5458\u4E2D\u5FC3</span></a><a href="/account"><span class="text">\u8D26\u6237</span></a><a href="/account/rec_vote"><span class="text">\u63A8\u8350\u7968</span></a><a href="/people/47115977/works_recommends?dcm=user-menu"><span class="text">\u63A8\u6587</span></a><a href="/account/feedback"><span class="text">\u53CD\u9988</span></a><a href="/account/setting"><span class="text">\u8BBE\u7F6E</span></a><a href="/logout?ck=kDa6" class="logout"><span class="text">\u9000\u51FA\u767B\u5F55</span></a></div></div></div></div><div class="search-container panel-container"><section class="search-section"><div><form action="/search" class="search-form"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none" class="search-icon"><circle cx="8.486" cy="8.486" r="7.736" stroke="#35393C" stroke-width="1.5"></circle><path fill="#fff" stroke="#35393C" stroke-width="1.2" d="M4.603 4.603a5.491 5.491 0 000 7.765"></path><path fill="#A6A6A6" stroke="#35393C" d="M13.685 14.39l.705-.705 2.55 2.55a.498.498 0 01-.704.706l-2.55-2.55z"></path></svg><input type="text" name="q" maxlength="60" autocomplete="off" placeholder="\u539F\u521B\u4F5C\u54C1 / \u540C\u4EBA\u6587 / \u7535\u5B50\u4E66 / \u4F5C\u8005 / \u8BD1\u8005 / \u51FA\u7248\u793E" value=""><button class="btn-search" type="submit">\u641C\u7D22</button></form></div></section><section class="search-sections-container"><section class="search-sections"><div><div class="recommend-header"><h3>\u70ED\u95E8\u641C\u7D22</h3></div><div class="keyword-list"><a href="/search?q=\u65E5\u504F\u98DF&amp;dcs=original-featured&amp;dcm=header" class="hot">\u65E5\u504F\u98DF</a><a href="/search?q=\u9519\u5A5A&amp;dcs=original-featured&amp;dcm=header" class="hot">\u9519\u5A5A</a><a href="/search?q=\u591C\u83BA\u4E0D\u6765&amp;dcs=original-featured&amp;dcm=header" class="hot">\u591C\u83BA\u4E0D\u6765</a><a href="/search?q=\u6625\u5FC3\u9677\u9631&amp;dcs=original-featured&amp;dcm=header" class="">\u6625\u5FC3\u9677\u9631</a><a href="/search?q=\u60C5\u4EBA&amp;dcs=original-featured&amp;dcm=header" class="">\u60C5\u4EBA</a><a href="/search?q=\u5C3C\u5361&amp;dcs=original-featured&amp;dcm=header" class="">\u5C3C\u5361</a><a href="/search?q=\u620F\u8C11\u6E38\u620F&amp;dcs=original-featured&amp;dcm=header" class="">\u620F\u8C11\u6E38\u620F</a><a href="/search?q=\u8DDF\u6211\u7ED3\u5A5A\u7684\u90A3\u4E2A\u9A97\u5B50&amp;dcs=original-featured&amp;dcm=header" class="">\u8DDF\u6211\u7ED3\u5A5A\u7684\u90A3\u4E2A\u9A97\u5B50</a><a href="/search?q=\u4E16\u672C\u65E0\u6843\u6E90&amp;dcs=original-featured&amp;dcm=header" class="">\u4E16\u672C\u65E0\u6843\u6E90</a><a href="/search?q=\u5BFB\u627E\u91D1\u798F\u771F&amp;dcs=original-featured&amp;dcm=header" class="">\u5BFB\u627E\u91D1\u798F\u771F</a></div></div><div><div class="recommend-header"><h3>\u4E3A\u4F60\u63A8\u8350</h3></div><div class="url-list"><a href="https://read.douban.com/annual/2022/romance?dcs=original-featured&amp;dcm=header">2022 \u5E74\u5EA6\u699C\u5355</a><a href="https://read.douban.com/original/finalized/limited-discount?dcs=original-featured&amp;dcm=header">6 \u90E8\u70ED\u95E8\u539F\u521B\u5C0F\u8BF4\u9650\u65F6\u534A\u4EF7</a><a href="https://read.douban.com/rally/5/?dcs=original-featured&amp;dcm=header">\u7B2C\u4E94\u5C4A\u957F\u7BC7\u62C9\u529B\u8D5B\u6B63\u5F0F\u5F00\u8D5B</a></div></div></section></section></div></header></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/mainHeader.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "mainFooter",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u795D\u798F",
      meta: [
        { name: "description", content: "\u8D3A\u5361 \u9001\u795D\u798F \u6D77\u62A5" },
        { name: "charset", content: "utf-8" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><footer class="ftco-footer"><div class="container"><div class="row mb-5 justify-content-between"><div class="col-sm-12 col-md-5"><div class="ftco-footer-widget mb-4"><h2 class="ftco-heading-2 mb-4 logo"><a href="#">Monarch</a></h2><p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p><h2 class="ftco-heading-2 mb-4">Connect with us</h2><ul class="ftco-footer-social list-unstyled mt-2"><li class="ftco-animate"><a href="#"><svg class="icon" width="50px" height="50.00px" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M815.25 80.23h-606.9c-111.86 0-202.87 91-202.87 202.88v470C5.48 865 96.5 956 208.35 956h606.89c111.87 0 202.88-91 202.88-202.88v-470c0.01-111.89-91-202.89-202.87-202.89zM706.43 449.74l213.14-229.11c11.03 18.34 17.76 39.56 17.76 62.49v379.13l-230.9-212.51z m108.82-288.71c14.84 0 28.89 3.05 42.06 7.92L511.79 540.34 166.3 168.95c13.17-4.87 27.22-7.92 42.05-7.92h606.9z m-711.21 59.6l213.13 229.11L86.28 662.25V283.12c0-22.92 6.73-44.15 17.76-62.49zM815.25 875.2h-606.9c-61.39 0-111.83-45.69-120.33-104.78l284.16-261.54 139.6 150.07L651.4 508.88l284.18 261.54c-8.5 59.09-58.95 104.78-120.33 104.78z" fill="#333333"></path></svg></a></li><li class="ftco-animate"><a href="#"><svg class="icon" width="50px" height="50.00px" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M670.208 368.128c10.24 0 20.48 1.024 30.72 2.048-27.136-127.488-163.328-222.208-318.976-222.208-173.568 0-316.416 118.272-316.416 268.8 0 87.04 47.104 158.208 126.464 213.504l-31.744 95.232 110.592-55.296c39.424 7.68 71.168 15.872 110.592 15.872 9.728 0 19.968-0.512 29.696-1.024-6.144-20.992-9.728-43.52-9.728-66.56 0-138.24 118.272-250.368 268.8-250.368zM500.224 282.624c24.064 0 39.424 15.872 39.424 39.424s-15.872 39.424-39.424 39.424-47.616-15.872-47.616-39.424c0-24.064 23.552-39.424 47.616-39.424zM278.528 361.472c-23.552 0-47.616-15.872-47.616-39.424s24.064-39.424 47.616-39.424 39.424 15.872 39.424 39.424c0.512 23.552-15.36 39.424-39.424 39.424z" fill="#09BB07"></path><path d="M958.464 614.912c0-126.464-126.464-229.376-268.8-229.376-150.528 0-268.8 102.912-268.8 229.376 0 126.976 118.272 229.376 268.8 229.376 31.744 0 63.488-7.68 94.72-15.872l86.528 47.616-23.552-78.848c64-48.128 111.104-111.104 111.104-182.272z m-355.84-39.936c-15.872 0-31.744-15.872-31.744-31.744s15.872-31.744 31.744-31.744c24.064 0 39.424 15.872 39.424 31.744 0.512 16.384-15.36 31.744-39.424 31.744z m174.08 0c-15.36 0-31.232-15.872-31.232-31.744s15.872-31.744 31.232-31.744c23.552 0 39.424 15.872 39.424 31.744 0 16.384-15.36 31.744-39.424 31.744z" fill="#09BB07"></path></svg></a></li></ul></div></div><div class="col-sm-12 col-md-6"><h2 class="ftco-heading-2 mb-4">Navigation</h2><div class="row"><div class="col-md-4"><div class="ftco-footer-widget"><ul class="list-unstyled"><li><a href="#">Home</a></li><li><a href="#">Services</a></li><li><a href="#">Work</a></li><li><a href="#">About</a></li><li><a href="#">Blog</a></li></ul></div></div><div class="col-md-4"><div class="ftco-footer-widget"><ul class="list-unstyled"><li><a href="#">Press</a></li><li><a href="#">Blog</a></li><li><a href="#">Contact</a></li><li><a href="#">Support</a></li><li><a href="#">Privacy</a></li></ul></div></div><div class="col-md-4"><div class="ftco-footer-widget"><ul class="list-unstyled"><li><a href="#">Privacy</a></li><li><a href="#">FAQ</a></li><li><a href="#">Careers</a></li><li><a href="#">Procedure</a></li><li><a href="#">Team</a></li></ul></div></div></div></div></div></div><div class="container-fluid px-0 py-5 bg-black"><div class="container"><div class="row"><div class="col-md-12 text-center"><p class="mb-0">Copyright \xA9 All rights reserved | This template is made with <i class="fa fa-heart color-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" rel="nofollow noopener">Colorlib</a></p></div></div></div></div></footer></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/mainFooter.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_mainHeader = __nuxt_component_0;
  const _component_mainFooter = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_mainHeader, null, null, _parent));
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(ssrRenderComponent(_component_mainFooter, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-d145cec0.mjs.map
