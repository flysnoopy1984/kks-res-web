const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('./_nuxt/index-styles.42f6bb8e.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.cf00f4cc.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.a001b7ed.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.072d89d7.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
